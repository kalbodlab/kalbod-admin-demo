Kalbod Admin Demo — راه‌اندازی در ویندوز

۱) پوشه kalbod-admin-demo را در محل دلخواه استخراج کنید.
۲) وارد پوشه استخراج‌شده شوید.
۳) در نوار آدرس File Explorer بنویسید cmd و Enter بزنید.
۴) این دستور را اجرا کنید:
   py -m http.server 4173
   اگر py کار نکرد:
   python -m http.server 4173
۵) در Chrome باز کنید:
   http://localhost:4173/

صفحات:
Dashboard  http://localhost:4173/#/dashboard
Inbox      http://localhost:4173/#/inbox
Customers  http://localhost:4173/#/customers
Orders     http://localhost:4173/#/orders
Agents     http://localhost:4173/#/agents
Workflows  http://localhost:4173/#/workflows
Channels   http://localhost:4173/#/channels
Settings   http://localhost:4173/#/settings

مهم:
- این نسخه فقط Demo محلی است.
- اطلاعات ساختگی هستند و به Backend یا Production وصل نیستند.
- تغییرات با Refresh پاک می‌شوند.
- برای توقف سرور در پنجره CMD کلیدهای Ctrl+C را بزنید.
- این بسته Service Worker ندارد تا مرحله اول نمایش ساده و قابل‌اعتماد بماند.
