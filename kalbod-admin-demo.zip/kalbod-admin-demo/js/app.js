/* Kalbod Admin Demo — local-only, synthetic data */
(() => {
'use strict';
const tenants=[{id:'tnt_demo_kalbod',name:'Kalbod Demo',plan:'pro',role:'owner'},{id:'tnt_demo_north',name:'North Studio',plan:'trial',role:'admin'}];
const customers=[
{id:'cus_01',tenant:'tnt_demo_kalbod',name:'مشتری نمایشی ۱',channel:'Telegram',handle:'@demo_one',phone:'0912***0001',city:'تهران',tag:'VIP',notes:'علاقه‌مند به چوب گردو.'},
{id:'cus_02',tenant:'tnt_demo_kalbod',name:'مشتری نمایشی ۲',channel:'Instagram',handle:'@demo_two',phone:'0912***0002',city:'کرج',tag:'جدید',notes:'اولین تماس از اینستاگرام.'},
{id:'cus_03',tenant:'tnt_demo_kalbod',name:'مشتری نمایشی ۳',channel:'Telegram',handle:'@demo_three',phone:'0912***0003',city:'اصفهان',tag:'عادی',notes:'سفارش قبلی تحویل شده.'},
{id:'cus_04',tenant:'tnt_demo_north',name:'مشتری نمایشی ۴',channel:'Website',handle:'demo@example.test',phone:'0912***0004',city:'شیراز',tag:'VIP',notes:'مشتری سازمانی.'}
];
const conversations=[
{id:'cnv_01',tenant:'tnt_demo_kalbod',customer:'cus_01',channel:'Telegram',unread:2,updated:'۲ دقیقه پیش',messages:[{dir:'in',text:'سلام، برای اتاق خواب کمد دیواری می‌خواستم.',time:'۱۰:۰۲'},{dir:'out',text:'سلام. عرض و ارتفاع دیوار را دارید؟',time:'۱۰:۰۳'},{dir:'in',text:'عرض ۳۲۰ سانت، ارتفاع ۲۸۰.',time:'۱۰:۰۴'}]},
{id:'cnv_02',tenant:'tnt_demo_kalbod',customer:'cus_02',channel:'Instagram',unread:0,updated:'۲۵ دقیقه پیش',messages:[{dir:'in',text:'قیمت میز جلو مبلی چقدره؟',time:'۰۹:۳۱'},{dir:'out',text:'بستگی به ابعاد و متریال دارد. اندازه‌تان چقدر است؟',time:'۰۹:۳۳'}]},
{id:'cnv_03',tenant:'tnt_demo_kalbod',customer:'cus_03',channel:'Telegram',unread:1,updated:'۱ ساعت پیش',messages:[{dir:'in',text:'سفارش قبلیم کی آماده می‌شه؟',time:'۰۸:۴۰'}]},
{id:'cnv_04',tenant:'tnt_demo_north',customer:'cus_04',channel:'Website',unread:0,updated:'دیروز',messages:[{dir:'in',text:'برای دفتر کار کتابخانه می‌خواستم.',time:'۱۶:۲۰'}]}
];
const orders=[
{id:'ord_01',tenant:'tnt_demo_kalbod',customer:'cus_01',title:'کمد دیواری',status:'in_progress',amount:'۴۸٬۰۰۰٬۰۰۰',created:'۱۴۰۵/۰۹/۰۲',dimensions:'۳۲۰×۲۸۰×۶۰',material:'MDF روکش گردو'},
{id:'ord_02',tenant:'tnt_demo_kalbod',customer:'cus_02',title:'میز جلو مبلی',status:'pending',amount:'۱۲٬۵۰۰٬۰۰۰',created:'۱۴۰۵/۰۹/۰۱',dimensions:'۱۱۰×۶۰×۴۵',material:'چوب راش'},
{id:'ord_03',tenant:'tnt_demo_north',customer:'cus_04',title:'کتابخانه',status:'done',amount:'۳۵٬۰۰۰٬۰۰۰',created:'۱۴۰۵/۰۸/۲۸',dimensions:'۲۴۰×۳۰×۲۰۰',material:'MDF سفید'}
];
const agents=[
{id:'a1',tenant:'tnt_demo_kalbod',name:'Sales Support',role:'پاسخ اولیه و واجد شرایط‌سازی',on:true,handled:128,avg:'۴۲ ثانیه',sat:'۹۴٪'},
{id:'a2',tenant:'tnt_demo_kalbod',name:'Technical Specialist',role:'ابعاد، متریال و نصب',on:true,handled:76,avg:'۵۸ ثانیه',sat:'۹۱٪'},
{id:'a3',tenant:'tnt_demo_kalbod',name:'Designer',role:'پیشنهاد طراحی و ترکیب',on:false,handled:0,avg:'—',sat:'—'},
{id:'a4',tenant:'tnt_demo_north',name:'Sales Support',role:'پاسخ اولیه',on:true,handled:12,avg:'۵۱ ثانیه',sat:'۸۹٪'}
];
const workflows=[
{id:'w1',tenant:'tnt_demo_kalbod',name:'Intake → Qualification',on:true,steps:['دریافت پیام از کانال','شناسایی یا ایجاد مشتری','استخراج نیاز','پاسخ عامل فروش']},
{id:'w2',tenant:'tnt_demo_kalbod',name:'Order Draft',on:false,steps:['تشخیص قصد سفارش','جمع‌آوری ابعاد و متریال','ساخت پیش‌نویس سفارش','تأیید مدیر']},
{id:'w3',tenant:'tnt_demo_north',name:'Intake → Qualification',on:true,steps:['دریافت پیام','ایجاد مشتری','پاسخ']}
];
const channels=[
{id:'ch1',tenant:'tnt_demo_kalbod',name:'Telegram',status:'نمایشی متصل',detail:'اتصال واقعی برقرار نیست'},
{id:'ch2',tenant:'tnt_demo_kalbod',name:'Instagram',status:'غیرفعال',detail:'اتصال واقعی برقرار نیست'},
{id:'ch3',tenant:'tnt_demo_kalbod',name:'WhatsApp',status:'برنامه‌ریزی‌شده',detail:'در نسخه نمایشی فقط طرح رابط است'},
{id:'ch4',tenant:'tnt_demo_north',name:'Website',status:'نمایشی متصل',detail:'اتصال واقعی برقرار نیست'}
];
const S={tenant:tenants[0].id,route:'dashboard',conversation:'cnv_01',chatOpen:false,query:'',orderFilter:'all'};
const $=s=>document.querySelector(s), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scoped=arr=>arr.filter(x=>x.tenant===S.tenant), customer=id=>customers.find(x=>x.id===id&&x.tenant===S.tenant), convo=id=>conversations.find(x=>x.id===id&&x.tenant===S.tenant);
const routeNames={dashboard:['داشبورد','▦'],inbox:['صندوق یکپارچه','✉'],customers:['مشتریان','◍'],orders:['سفارش‌ها','▤'],agents:['عامل‌های هوشمند','✦'],workflows:['گردش‌کارها','⇄'],channels:['کانال‌ها','⌁'],settings:['تنظیمات','⚙']};
const navGroups=[{items:['dashboard','inbox','customers','orders']},{label:'اتوماسیون',items:['agents','workflows','channels']},{label:'فضای کاری',items:['settings']}];
const tabs=['dashboard','inbox','customers','orders','settings'];
function toast(msg){const el=document.createElement('div');el.className='toast';el.textContent=msg;$('#toasts').append(el);setTimeout(()=>el.remove(),2600)}
function badge(text,kind=''){return `<span class="badge ${kind}">${esc(text)}</span>`}
function kpi(label,value,sub){return `<div class="card kpi"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div><div class="kpi-delta">${sub}</div></div>`}
function dashboard(){
const cs=scoped(conversations), cu=scoped(customers), os=scoped(orders), ch=scoped(channels), unread=cs.reduce((a,c)=>a+c.unread,0);
const rows=cs.map(c=>{const u=customer(c.customer),m=c.messages.at(-1);return `<tr data-open-chat="${c.id}"><td class="primary">${esc(u?.name||'—')}</td><td>${badge(c.channel)}</td><td>${esc(m?.text||'')}</td><td class="faint">${c.updated}</td></tr>`}).join('');
return `<div class="grid g4">${kpi('گفتگوهای خوانده‌نشده',unread,'در این فضای کاری')}${kpi('مشتریان',cu.length,'مشتری نمایشی')}${kpi('سفارش‌ها',os.length,'همه وضعیت‌ها')}${kpi('کانال‌ها',ch.length,'تعریف‌شده در Demo')}</div>
<div class="grid g2" style="margin-top:14px"><div class="card"><div class="card-head"><h3>حجم گفتگو — ۷ روز اخیر</h3></div><div class="card-body"><div class="chart">${[12,18,9,22,17,26,14].map(v=>`<div class="bar" style="height:${v*4}px"></div>`).join('')}</div><div class="chart-labels"><span>ش</span><span>ی</span><span>د</span><span>س</span><span>چ</span><span>پ</span><span>ج</span></div></div></div>
<div class="card"><div class="card-head"><h3>وضعیت کانال‌ها</h3></div><div class="card-body">${ch.map(c=>`<div class="row" style="padding:7px 0">${badge(c.status,c.status.includes('متصل')?'ok':'muted')}<span>${esc(c.name)}</span></div>`).join('')}</div></div></div>
<div class="card" style="margin-top:14px"><div class="card-head"><h3>آخرین گفتگوها</h3><span class="spacer"></span><a class="btn btn-sm" href="#/inbox">مشاهده همه</a></div><div class="table-wrap"><table class="table"><thead><tr><th>مشتری</th><th>کانال</th><th>آخرین پیام</th><th>زمان</th></tr></thead><tbody>${rows||'<tr><td class="empty">گفتگویی وجود ندارد</td></tr>'}</tbody></table></div></div>`;
}
function inbox(){
const list=scoped(conversations),active=convo(S.conversation)||list[0],u=active?customer(active.customer):null;
if(active)S.conversation=active.id;
return `<div class="inbox ${S.chatOpen?'chat-open':''}"><div class="conv-list">${list.map(c=>{const owner=customer(c.customer),last=c.messages.at(-1);return `<div class="conv ${active?.id===c.id?'active':''}" data-conversation="${c.id}" tabindex="0" role="button"><div class="conv-avatar">${esc(owner?.name?.slice(-1)||'؟')}</div><div class="conv-main"><div class="conv-top"><span class="conv-name">${esc(owner?.name||'—')}</span><span class="conv-time">${c.updated}</span></div><div class="conv-preview">${esc(last?.text||'')}</div></div></div>`}).join('')||'<div class="empty">گفتگویی وجود ندارد</div>'}</div>
<div class="thread-pane"><div class="thread-head"><button class="icon-btn" id="back-btn" aria-label="بازگشت">→</button><div><strong>${esc(u?.name||'—')}</strong><div class="faint">${esc(active?.channel||'')} · ${esc(u?.handle||'')}</div></div><span class="spacer"></span>${badge(u?.tag||'—','info')}</div>
<div class="thread-body" id="thread-body">${(active?.messages||[]).map(m=>`<div><div class="msg ${m.dir}">${esc(m.text)}</div><div class="msg-time">${m.time}</div></div>`).join('')}</div><div class="compose"><input class="input" id="reply-input" placeholder="پاسخ نمایشی بنویسید…" aria-label="متن پاسخ"><button class="btn btn-primary" id="send-btn">ارسال</button></div></div>
<div class="detail"><div class="kpi-label">اطلاعات مشتری</div><strong>${esc(u?.name||'—')}</strong><p class="muted">${esc(u?.phone||'')}</p><p>${badge(u?.city||'—')}</p><button class="btn btn-block" data-customer="${u?.id||''}">پروفایل مشتری</button><p class="faint" style="font-size:10px;margin-top:14px">این گفتگو کاملاً نمایشی است.</p></div></div>`;
}
function customersView(){
const rows=scoped(customers).filter(c=>!S.query||[c.name,c.handle,c.phone].some(v=>v.includes(S.query)));
return `<div class="toolbar"><input class="input" id="search-input" value="${esc(S.query)}" placeholder="جست‌وجوی نام، شناسه یا تلفن…"><button class="btn btn-primary" data-action="new-customer">+ مشتری جدید</button></div><div class="card table-wrap"><table class="table"><thead><tr><th>نام</th><th>کانال</th><th>شناسه</th><th>تلفن</th><th>شهر</th></tr></thead><tbody>${rows.map(c=>`<tr data-customer="${c.id}"><td class="primary">${esc(c.name)}</td><td>${badge(c.channel)}</td><td>${esc(c.handle)}</td><td>${esc(c.phone)}</td><td>${esc(c.city)}</td></tr>`).join('')||'<tr><td class="empty">موردی یافت نشد</td></tr>'}</tbody></table></div>`;
}
function ordersView(){
const labels={pending:'در انتظار',in_progress:'در جریان',done:'تحویل‌شده'},tones={pending:'warn',in_progress:'info',done:'ok'};
const all=scoped(orders),shown=S.orderFilter==='all'?all:all.filter(o=>o.status===S.orderFilter);
return `<div class="toolbar" style="flex-wrap:wrap">${[['all','همه'],['pending','در انتظار'],['in_progress','در جریان'],['done','تحویل‌شده']].map(([k,v])=>`<button class="btn btn-sm ${S.orderFilter===k?'btn-primary':''}" data-filter="${k}">${v}</button>`).join('')}<span class="spacer"></span><button class="btn btn-primary" data-action="new-order">+ سفارش جدید</button></div><div class="card table-wrap"><table class="table"><thead><tr><th>عنوان</th><th>مشتری</th><th>وضعیت</th><th>مبلغ (تومان)</th><th>تاریخ</th></tr></thead><tbody>${shown.map(o=>`<tr data-order="${o.id}"><td class="primary">${esc(o.title)}</td><td>${esc(customer(o.customer)?.name||'—')}</td><td>${badge(labels[o.status],tones[o.status])}</td><td>${esc(o.amount)}</td><td>${esc(o.created)}</td></tr>`).join('')||'<tr><td class="empty">سفارشی وجود ندارد</td></tr>'}</tbody></table></div>`;
}
function agentsView(){return `<div class="grid g3">${scoped(agents).map(a=>`<div class="card agent"><div class="agent-head"><div class="agent-icon">✦</div><div><strong>${esc(a.name)}</strong><div class="faint">${esc(a.role)}</div></div><span class="spacer"></span><label class="switch"><input type="checkbox" data-agent="${a.id}" ${a.on?'checked':''}><span></span></label></div>${badge(a.on?'فعال':'خاموش',a.on?'ok':'muted')}<div class="agent-stats"><div class="agent-stat"><b>${a.handled}</b><span>گفتگو</span></div><div class="agent-stat"><b>${a.avg}</b><span>میانگین پاسخ</span></div><div class="agent-stat"><b>${a.sat}</b><span>رضایت</span></div></div></div>`).join('')||'<div class="empty">عاملی تعریف نشده است</div>'}</div>`}
function workflowsView(){return `<div class="grid g2">${scoped(workflows).map(w=>`<div class="card"><div class="card-head"><h3>${esc(w.name)}</h3><span class="spacer"></span><label class="switch"><input type="checkbox" data-workflow="${w.id}" ${w.on?'checked':''}><span></span></label></div><div class="card-body">${w.steps.map((s,i)=>`<div class="step"><div class="step-dot"></div><div class="step-text">${i+1}. ${esc(s)}</div></div>`).join('')}</div></div>`).join('')||'<div class="empty">گردش‌کاری تعریف نشده است</div>'}</div>`}
function channelsView(){return `<div class="grid g2">${scoped(channels).map(c=>`<div class="card"><div class="card-head"><h3>${esc(c.name)}</h3><span class="spacer"></span>${badge(c.status,c.status.includes('متصل')?'ok':'muted')}</div><div class="card-body"><p class="muted">${esc(c.detail)}</p><button class="btn btn-sm" data-action="channel">پیکربندی نمایشی</button></div></div>`).join('')}</div>`}
function settingsView(){const t=tenants.find(t=>t.id===S.tenant);return `<div class="grid g2"><div class="card"><div class="card-head"><h3>فضای کاری</h3></div><div class="card-body"><div class="kpi-label">نام</div><strong>${esc(t.name)}</strong><p class="kpi-label">شناسه</p><code>${esc(t.id)}</code><p>${badge(t.plan,'info')} ${badge(t.role)}</p></div></div><div class="card"><div class="card-head"><h3>وضعیت اتصال</h3></div><div class="card-body"><div class="kpi-label">حالت</div><strong>Local Demo / Mock</strong><p class="muted">هیچ API، دیتابیس یا سرویس خارجی فراخوانی نمی‌شود.</p></div></div><div class="card" style="grid-column:1/-1"><div class="card-head"><h3>نکته مهم</h3></div><div class="card-body muted">این نسخه برای بررسی ظاهر و جریان صفحات ساخته شده است. اطلاعات ساختگی هستند و با بارگذاری مجدد صفحه به حالت اولیه برمی‌گردند.</div></div></div>`}
const views={dashboard,inbox,customers:customersView,orders:ordersView,agents:agentsView,workflows:workflowsView,channels:channelsView,settings:settingsView};
function renderNav(){
const unread=scoped(conversations).reduce((n,c)=>n+c.unread,0);
$('#nav').innerHTML=navGroups.map(g=>(g.label?`<div class="nav-group-label">${g.label}</div>`:'')+g.items.map(k=>`<a class="nav-item ${S.route===k?'active':''}" href="#/${k}"><span class="nav-icon">${routeNames[k][1]}</span><span>${routeNames[k][0]}</span>${k==='inbox'&&unread?`<span class="nav-badge">${unread}</span>`:''}</a>`).join('')).join('');
$('#tabbar').innerHTML=tabs.map(k=>`<a class="tab ${S.route===k?'active':''}" href="#/${k}"><span class="tab-icon">${routeNames[k][1]}</span><span>${routeNames[k][0]}</span></a>`).join('');
}
function render(){
const raw=location.hash.replace(/^#\/?/,'');S.route=views[raw]?raw:'dashboard';
$('#page-title').textContent=routeNames[S.route][0];$('#view').innerHTML=views[S.route]();renderNav();
$('#tenant-select').value=S.tenant;$('#sidebar').classList.remove('open');
if(S.route==='inbox'){const t=$('#thread-body');if(t)t.scrollTop=t.scrollHeight}
bind();
}
function openModal(title,html,saveLabel,saveFn){
const root=$('#modal-root');root.innerHTML=`<div class="modal" role="dialog" aria-modal="true"><div class="modal-head"><h3>${esc(title)}</h3><span class="spacer"></span><button class="icon-btn" data-close>×</button></div><div class="modal-body">${html}</div><div class="modal-actions"><button class="btn" data-close>انصراف</button><button class="btn btn-primary" id="modal-save">${saveLabel}</button></div></div>`;root.hidden=false;root.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{root.hidden=true;root.innerHTML=''});root.onclick=e=>{if(e.target===root){root.hidden=true;root.innerHTML=''}};root.querySelector('#modal-save').onclick=()=>saveFn(root);
}
function customerModal(id){const c=customer(id);if(!c)return;const os=scoped(orders).filter(o=>o.customer===id);openModal('پروفایل مشتری',`<h3>${esc(c.name)}</h3><p>${esc(c.handle)} · ${esc(c.phone)}</p><p>${badge(c.channel)} ${badge(c.tag,'info')} ${badge(c.city)}</p><div class="field"><label>یادداشت</label><div>${esc(c.notes)}</div></div><div class="field"><label>سفارش‌ها (${os.length})</label>${os.map(o=>`<p>${esc(o.title)} — ${esc(o.amount)}</p>`).join('')||'سفارشی ثبت نشده'}`,'بستن',()=>{$('#modal-root').hidden=true;$('#modal-root').innerHTML=''});}
function orderModal(id){const o=orders.find(x=>x.id===id&&x.tenant===S.tenant);if(!o)return;openModal('ویرایش سفارش',`<div class="field"><label>عنوان</label><input class="input" id="o-title" value="${esc(o.title)}"></div><div class="field"><label>وضعیت</label><select class="input" id="o-status"><option value="pending">در انتظار</option><option value="in_progress">در جریان</option><option value="done">تحویل‌شده</option></select></div><div class="field"><label>ابعاد</label><input class="input" id="o-dim" value="${esc(o.dimensions)}"></div><div class="field"><label>متریال</label><input class="input" id="o-mat" value="${esc(o.material)}"></div><div class="field"><label>مبلغ</label><input class="input" id="o-amount" value="${esc(o.amount)}"></div>`,'ذخیره نمایشی',root=>{o.title=root.querySelector('#o-title').value.trim()||o.title;o.status=root.querySelector('#o-status').value;o.dimensions=root.querySelector('#o-dim').value;o.material=root.querySelector('#o-mat').value;o.amount=root.querySelector('#o-amount').value;root.hidden=true;root.innerHTML='';toast('تغییرات فقط در حافظه مرورگر ذخیره شد');render()});$('#modal-root #o-status').value=o.status;}
function bind(){
$('#view').querySelectorAll('[data-open-chat]').forEach(el=>el.onclick=()=>{S.conversation=el.dataset.openChat;S.chatOpen=true;location.hash='#/inbox';render()});
$('#view').querySelectorAll('[data-conversation]').forEach(el=>{const go=()=>{S.conversation=el.dataset.conversation;S.chatOpen=true;render()};el.onclick=go;el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}}});
const back=$('#back-btn');if(back)back.onclick=()=>{S.chatOpen=false;render()};
const send=$('#send-btn');if(send){const act=()=>{const inp=$('#reply-input'),v=inp.value.trim(),c=convo(S.conversation);if(!v||!c)return;c.messages.push({dir:'out',text:v,time:'اکنون'});c.updated='اکنون';toast('پیام نمایشی ثبت شد؛ ارسال واقعی انجام نشد');render()};send.onclick=act;$('#reply-input').onkeydown=e=>{if(e.key==='Enter')act()}}
const search=$('#search-input');if(search)search.oninput=e=>{S.query=e.target.value;const pos=e.target.selectionStart;const html=customersView();$('#view').innerHTML=html;bind();const n=$('#search-input');n.focus();n.setSelectionRange(pos,pos)};
$('#view').querySelectorAll('[data-customer]').forEach(el=>el.onclick=()=>customerModal(el.dataset.customer));
$('#view').querySelectorAll('[data-order]').forEach(el=>el.onclick=()=>orderModal(el.dataset.order));
$('#view').querySelectorAll('[data-filter]').forEach(el=>el.onclick=()=>{S.orderFilter=el.dataset.filter;render()});
$('#view').querySelectorAll('[data-agent]').forEach(el=>el.onchange=()=>{const a=agents.find(x=>x.id===el.dataset.agent&&x.tenant===S.tenant);if(a){a.on=el.checked;toast('وضعیت عامل در Demo تغییر کرد')}render()});
$('#view').querySelectorAll('[data-workflow]').forEach(el=>el.onchange=()=>{const w=workflows.find(x=>x.id===el.dataset.workflow&&x.tenant===S.tenant);if(w){w.on=el.checked;toast('وضعیت گردش‌کار در Demo تغییر کرد')}render()});
$('#view').querySelectorAll('[data-action]').forEach(el=>el.onclick=()=>{if(el.dataset.action==='channel')return toast('پیکربندی واقعی کانال در این نسخه فعال نیست');if(el.dataset.action==='new-customer')openModal('افزودن مشتری',`<div class="field"><label>نام مشتری</label><input class="input" id="c-name"></div><div class="field"><label>کانال</label><select class="input" id="c-channel"><option>Telegram</option><option>Instagram</option><option>Website</option></select></div><div class="field"><label>شناسه</label><input class="input" id="c-handle"></div><div class="field"><label>تلفن</label><input class="input" id="c-phone"></div>`,'ثبت نمایشی',root=>{const name=root.querySelector('#c-name').value.trim();if(!name)return toast('نام مشتری الزامی است');customers.push({id:'cus_'+Date.now(),tenant:S.tenant,name,channel:root.querySelector('#c-channel').value,handle:root.querySelector('#c-handle').value,phone:root.querySelector('#c-phone').value,city:'—',tag:'جدید',notes:'ثبت نمایشی'});root.hidden=true;root.innerHTML='';render();toast('مشتری نمایشی اضافه شد')});
if(el.dataset.action==='new-order'){const opts=scoped(customers).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');openModal('سفارش جدید',`<div class="field"><label>عنوان</label><input class="input" id="n-title"></div><div class="field"><label>مشتری</label><select class="input" id="n-customer">${opts}</select></div><div class="field"><label>مبلغ (تومان)</label><input class="input" id="n-amount"></div>`,'ثبت نمایشی',root=>{const title=root.querySelector('#n-title').value.trim();if(!title)return toast('عنوان سفارش الزامی است');orders.push({id:'ord_'+Date.now(),tenant:S.tenant,customer:root.querySelector('#n-customer').value,title,status:'pending',amount:root.querySelector('#n-amount').value||'—',created:'امروز',dimensions:'—',material:'—'});root.hidden=true;root.innerHTML='';render();toast('سفارش نمایشی اضافه شد')})}
});
}
$('#tenant-select').onchange=e=>{S.tenant=e.target.value;S.conversation=scoped(conversations)[0]?.id||null;S.chatOpen=false;S.query='';S.orderFilter='all';render();toast('فضای کاری نمایشی تغییر کرد')};
$('#menu-btn').onclick=()=>$('#sidebar').classList.toggle('open');
window.addEventListener('hashchange',()=>{S.chatOpen=false;render()});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#modal-root').hidden){$('#modal-root').hidden=true;$('#modal-root').innerHTML=''}});
if(!location.hash)location.hash='#/dashboard';else render();
})();
